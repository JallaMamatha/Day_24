﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_24
{
    class Exception5
    {
        static void Main(string[] args)
        {
            bool isvalid = true;

            string valid = isvalid.ToString();
            Char x = Convert.ToChar(120);
            Console.WriteLine(x);


        }
    }
}
