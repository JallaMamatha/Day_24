﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Virtusa
{
    class Dotnet
    {
        public string pid, pname;
        public Dotnet()
        {
            Console.WriteLine("PID and PNAME");
            pid = Console.ReadLine();
            pname = Console.ReadLine();
        }
    }
}
namespace Edureka
{
    class Trainers
    {
        public string tid, tname;
        public Trainers()
        {
            Console.WriteLine("TID and TNAME");
            tid = Console.ReadLine();
            tname = Console.ReadLine();
        }
    }
}

namespace Day_24
{
    class Program8
    {
        static void Main(string[] args)
        {
            Virtusa.Dotnet ob = new Virtusa.Dotnet();
            Edureka.Trainers E = new Edureka.Trainers();
        }
    }
}
