﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_24
{
    interface  Functions
    {
        void call();
        void text();
        void browse();
    }
    class phone : Functions
    {
        public void call()
        {
            Console.WriteLine("In call function");
        }
        public void text()
        {
            Console.WriteLine("In text function");
        }
        public void browse()
        {
            Console.WriteLine("In browse function");
        }
    }
    class Program7
    {
        static void Main(string[] args)
        {
            Functions ob = new phone();
            ob.call();
            ob.text();
            ob.browse();

        }
    }

}
