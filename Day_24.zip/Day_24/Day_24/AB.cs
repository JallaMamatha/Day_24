﻿using System;

namespace Day_24
{
    class Myexception : Exception
    {
        public Myexception(string msg):base(msg)
        {
            Console.WriteLine("__________MY OWN EXCEPTION_____________");
        }
    }
    internal  class AB
    {
        public int score;
        public AB()
        {
            Console.WriteLine("Enter the score");
            score = int.Parse(Console.ReadLine());
        }
        public void eligible()
        {
            if (score < 60)
                throw new Myexception("NOT ELIGIBLE");
            else
                Console.WriteLine("ELIGIBLE");
        }
    }
}
