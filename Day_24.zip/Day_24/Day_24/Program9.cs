﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_24
{
    interface All
    {
        void add();
        void sub();
        void disp();
    }

    abstract class Cal: All
    {
        public void add()
        {
            Console.WriteLine(4+5);
        }

        public abstract void sub();
        public abstract void disp();
    }
    class ImpCal : Cal
    {
        public override void sub()
        {
            Console.WriteLine(6-7);
        }
        public override void disp()
        {
            Console.WriteLine("i am in disp");
        }
    }
    class Program9
    {
        static void Main(string[] args)
        {
            All ob = new ImpCal();
            ob.add();
            ob.sub();
            ob.disp();
        }
    }
}
