﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_24
{

    class Dancers
    {
        private string name;

        public string Fullname
        {
            
                 get
                {
                    return name;
                }
            set
            {
                name = value;
            }
            
        }

        public void display()
        {
            Console.WriteLine("private name = "+name);
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Dancers ob = new Dancers();
            ob.Fullname = "MMMMM";
            Console.WriteLine("Dancer name = " + ob.Fullname);
            ob.display();
             
        }
    }
}
