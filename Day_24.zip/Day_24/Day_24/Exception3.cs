﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_24
{
    class Exception3
    {
        static void Main(string[] args)
        {
            int x;
            Console.WriteLine("Enter x = ");
            try
            {
                x = int.Parse(Console.ReadLine());
                x = x + 40;
                Console.WriteLine("NEW X =" + x);
            }
            catch (FormatException)
            {
                Console.WriteLine("Please enter the correct number");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                Console.WriteLine("I will get executed no matter what");
            }
        }
    }
}
