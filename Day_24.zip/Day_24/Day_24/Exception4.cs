﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_24
{
    class Exception4
    {
        static void Main(string[] args)
        {
            string s = null;
            int x = int.Parse(Console.ReadLine());

            if (x >= 10)
                s = "SOMETHING";
            try
            {
                Console.WriteLine(s.Length);
            }
            catch(NullReferenceException)
            {
                Console.WriteLine("S is null");
            }
        }
    }
}
