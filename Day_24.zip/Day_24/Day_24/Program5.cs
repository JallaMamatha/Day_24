﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_24
{

    class x
    {
    public virtual void dosomething()
        {
            Console.WriteLine("A--> do something");
        }
    }
    class y : x
    {
        public sealed override void dosomething()
        {
            Console.WriteLine("Y--> do something");
        }
    }
    class z : y
    {
       // public override void dosomething()
       
    }


    class Program5
    {
    }
}
