﻿using System;
using System.Text.RegularExpressions;



namespace Day_24
{
    class Server
    {
        public string Servername { get; set; }

    }
    class MyExcept : Exception
    {
        public MyExcept(string s) : base(String.Format("Invalid Servername: {0} ", s))
        {

        }
    }
    class Exception7
    {
        static void valid(Server ob)
        {
            Regex regex = new Regex("^[a-zA-Z]{7}$");

            if (!regex.IsMatch(ob.Servername))
                throw new MyExcept(ob.Servername);
        }
        static void Main(string[] args)
        {
            Server ob = null;

            try
            {
                ob = new Server();

                Console.WriteLine("Enter the serverName");
                ob.Servername = Console.ReadLine();
                valid(ob);
            }
            catch(MyExcept e)
            {
                Console.WriteLine(e.Message);
            }
           
        }
    }
}
